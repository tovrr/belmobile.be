import { fetchMarketData } from './lib/market-intelligence/scrapers';

async function test() {
    console.log("Testing Scraper for iPhone 13 in isolation...");
    try {
        const result = await fetchMarketData('Apple', 'iPhone 13');
        console.log("RESULT:", JSON.stringify(result, null, 2));
    } catch (e) {
        console.error("CRITICAL FAILURE:", e);
    }
}

test();
