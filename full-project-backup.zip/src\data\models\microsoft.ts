export const MODELS = {
    tablet: { 'Surface Pro 9': 700, 'Surface Go 3': 300 }
};

export const SPECS = {
    'Surface Pro 9': ['128GB', '256GB', '512GB', '1TB']
};
