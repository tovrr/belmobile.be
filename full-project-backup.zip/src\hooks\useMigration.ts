import { useState } from 'react';
import { collection, getDocs, writeBatch, doc } from 'firebase/firestore';
import { db } from '../firebase';
import { RepairPriceRecord } from '../types';

export const useMigration = () => {
    const [isMigrating, setIsMigrating] = useState(false);
    const [migrationStatus, setMigrationStatus] = useState<string>('');
    const [progress, setProgress] = useState(0);

    const migrateData = async () => {
        setIsMigrating(true);
        setMigrationStatus('Fetching legacy data...');
        setProgress(0);

        try {
            // 1. Fetch all prices
            const snapshot = await getDocs(collection(db, 'repair_prices'));
            const allDocs = snapshot.docs;

            // We process ALL documents to ensure canonical ID enforcement and manual work restoration
            const totalDocs = allDocs.length;
            const robustIds = new Set(allDocs.filter(d => !!d.data().issueId).map(d => d.id.toLowerCase()));

            console.log(`Found ${totalDocs} total documents. Enforcing canonical synchronization...`);
            setMigrationStatus(`Processing ${totalDocs} records for recovery...`);

            const newRecords: RepairPriceRecord[] = [];

            // 2. Parse and Transform ALL documents
            for (const docSnap of allDocs) {
                const data = docSnap.data();

                // Helper to standardize legacy IDs (e.g. 'Apple-iPhone-11-reparation' -> 'apple-iphone-11')
                const standardizeId = (id: string) => {
                    return id.toLowerCase()
                        .replace(/-reparation$/, '')
                        .replace(/-reparatie$/, '')
                        .replace(/-repair$/, '')
                        .replace(/-prix$/, '')
                        .replace(/-price$/, '')
                        .replace(/-prijs$/, '')
                        .replace(/-bruxelles$/, '')
                        .replace(/-brussel$/, '')
                        .replace(/-brussels$/, '')
                        .replace(/-achat$/, '')
                        .replace(/-scherm$/, '')
                        .replace(/-ecran$/, '')
                        .replace(/-screen$/, '')
                        .replace(/-batterie$/, '')
                        .replace(/-batterij$/, '')
                        .replace(/-battery$/, '')
                        .replace(/-plus$/, '-plus') // Just to be safe with createSlug logic
                        .replace(/[^a-z0-9]+/g, '-');
                };

                const rawId = docSnap.id;
                let deviceId = standardizeId(rawId);

                // Quick Fix for missing brands in common legacy IDs
                if (deviceId.startsWith('iphone')) deviceId = 'apple-' + deviceId;
                if (deviceId.startsWith('ipad')) deviceId = 'apple-' + deviceId;
                if (deviceId.startsWith('galaxy')) deviceId = 'samsung-' + deviceId;
                if (deviceId.startsWith('pixel')) deviceId = 'google-' + deviceId;
                if (deviceId.startsWith('nintendo-') && !deviceId.includes('switch')) deviceId = 'nintendo-switch';
                if (deviceId === 'switch' || deviceId === 'switch-lite' || deviceId === 'switch-oled') deviceId = 'nintendo-' + deviceId;

                // CRITICAL: De-duplicate brand prefixes (e.g. apple-apple-iphone -> apple-iphone)
                const brands = ['apple', 'samsung', 'google', 'huawei', 'nintendo', 'sony', 'microsoft', 'xiaomi', 'oppo', 'realme', 'motorola'];
                for (const brand of brands) {
                    const doublePrefix = `${brand}-${brand}-`;
                    if (deviceId.startsWith(doublePrefix)) {
                        deviceId = deviceId.replace(doublePrefix, `${brand}-`);
                    }
                }

                // Helper to add record
                const addRecord = (issueId: string, variants: Record<string, string>, price: number | string | null | undefined) => {
                    if (price === undefined || price === null) return;

                    // Improved Numeric Parsing (handles "0,00", "150.00 €", "Call Us", etc.)
                    let numPrice = -2;
                    if (typeof price === 'number') {
                        numPrice = price;
                    } else if (typeof price === 'string') {
                        const cleanPrice = price.replace(/[^\d.,-]/g, '').replace(',', '.');
                        numPrice = cleanPrice === '' ? 0 : Number(cleanPrice);
                        // If it contains "demande" or "request", force to 0
                        if (price.toLowerCase().includes('demande') || price.toLowerCase().includes('request')) {
                            numPrice = 0;
                        }
                    }

                    if (isNaN(numPrice) || numPrice < -1) return;

                    // Construct the ID to check for existing robust record
                    const variantValues = Object.entries(variants)
                        .sort((a, b) => a[0].localeCompare(b[0]))
                        .map(([, v]) => v)
                        .join('-') || 'base';
                    const targetDocId = `${deviceId}_${issueId}_${variantValues}`;

                    // RECOVERY LOGIC:
                    // During this emergency restoration, we OVERWRITE any existing robust record
                    // if the legacy record has a non-zero/non-null price.
                    // This ensures the user's "heavy work" from the old site beats any fresh seeder defaults.
                    if (robustIds.has(targetDocId.toLowerCase())) {
                        console.log(`[Migration] Manual Restoration: Overwriting robust record ${targetDocId} with legacy price ${numPrice}`);
                    }

                    // HEURISTIC: Is this likely manual?
                    // Non-standard prices (not 110, 180, etc.) are likely manual.
                    const isSystemDefault = numPrice === 110 || numPrice === 180 || numPrice === 120 || numPrice === 90;
                    const looksManual = numPrice > 0 && !isSystemDefault && numPrice !== 199 && numPrice !== 349 && numPrice !== 499;
                    const isManual = numPrice === 0 || numPrice === -1 || looksManual;

                    newRecords.push({
                        deviceId,
                        issueId,
                        variants,
                        price: numPrice,
                        currency: 'EUR',
                        isActive: true,
                        isManual,
                        updatedAt: new Date().toISOString(),
                        migrationSource: docSnap.id
                    });
                };

                // --- Screens ---
                const isSamsungSNA = deviceId.startsWith('samsung-galaxy-s') || deviceId.startsWith('samsung-galaxy-note') || deviceId.startsWith('samsung-galaxy-a') || deviceId.startsWith('samsung-galaxy-z');

                const scanPrice = (legacyKey: string, issueId: string, variants: Record<string, string> = {}) => {
                    // 1. Direct Field
                    if (data[legacyKey] !== undefined) {
                        addRecord(issueId, variants, data[legacyKey]);
                    }
                    // 2. Nested Prices
                    if (data.prices && typeof data.prices === 'object' && data.prices[legacyKey] !== undefined) {
                        addRecord(issueId, variants, data.prices[legacyKey]);
                    }
                };

                scanPrice('screen_generic', 'screen', { quality: 'generic-lcd' });
                scanPrice('screen_oled', 'screen', { quality: 'oled-soft' });

                if (data.screen_original !== undefined || (data.prices?.screen_original !== undefined)) {
                    const quality = isSamsungSNA ? 'original-service-pack' : 'original-refurb';
                    scanPrice('screen_original', 'screen', { quality });
                }

                scanPrice('screen_digitizer', 'screen_digitizer');
                scanPrice('screen_top', 'screen_upper');
                scanPrice('screen_bottom', 'screen_bottom');


                // --- Direct Mappings (Unified with Legacy Fields) ---
                const directMaps: Record<string, string> = {
                    battery: 'battery',
                    charging: 'charging', // Add both just in case
                    charging_port: 'charging',
                    back_glass: 'back_glass',
                    camera_rear: 'camera_rear',
                    camera_front: 'camera_front',
                    loud_speaker: 'audio',
                    ear_speaker: 'audio',
                    microphone: 'audio',
                    speaker: 'audio',
                    power_button: 'buttons',
                    volume_button: 'buttons',
                    water_damage: 'water',
                    water: 'water',
                    diagnostic: 'diagnostic',
                    software_repair: 'software',
                    software: 'software',
                    // Console/Handheld Specific
                    hdmi: 'hdmi',
                    joystick: 'joystick',
                    housing: 'housing',
                    full_housing: 'housing',
                    chassis: 'housing',
                    storage: 'storage',
                    disc: 'disc_drive',
                    card_reader: 'card_reader',
                    microsoldering: 'microsoldering',
                    soldering: 'microsoldering',
                    micro_soldering: 'microsoldering',
                    'micro-soldering': 'microsoldering',
                    microsoldure: 'microsoldering',
                    soldure: 'microsoldering',
                    haut_parleur: 'audio',
                    'haut-parleur': 'audio',
                    vitre_arriere: 'back_glass',
                    'vitre-arriere': 'back_glass',
                    rear_glass: 'back_glass',
                    charge: 'charging',
                    'charging-port': 'charging',
                    connector: 'charging'
                };

                Object.entries(directMaps).forEach(([legacyKey, newIssueId]) => {
                    scanPrice(legacyKey, newIssueId);
                });

                // Check for generic matches if not caught above
                const standardIssues = ['audio', 'water', 'camera_rear', 'camera_front', 'back_glass', 'microsoldering'];
                standardIssues.forEach(issue => {
                    scanPrice(issue, issue);
                });
            }

            console.log(`Generated ${newRecords.length} new pricing records.`);
            setMigrationStatus(`Generated ${newRecords.length} records. Writing to database...`);

            // 3. Batch Write (limit 450 per batch)
            const BATCH_SIZE = 450;
            for (let i = 0; i < newRecords.length; i += BATCH_SIZE) {
                const batch = writeBatch(db);
                const chunk = newRecords.slice(i, i + BATCH_SIZE);

                chunk.forEach(record => {
                    const variantValues = Object.entries(record.variants || {})
                        .sort((a, b) => a[0].localeCompare(b[0]))
                        .map(([, v]) => v)
                        .join('-') || 'base';

                    const docId = `${record.deviceId}_${record.issueId}_${variantValues}`;
                    const docRef = doc(db, 'repair_prices', docId);
                    batch.set(docRef, record);
                });

                await batch.commit();

                const currentProgress = Math.min(100, Math.round(((i + chunk.length) / newRecords.length) * 100));
                setProgress(currentProgress);
                setMigrationStatus(`Writing batch... ${currentProgress}%`);
            }

            setMigrationStatus('Migration Complete! ✅');
            alert(`Migration Success!\nConverted ${totalDocs} devices into ${newRecords.length} granular records.`);

        } catch (error) {
            console.error("Migration failed:", error);
            setMigrationStatus('Migration Failed. Check console.');
            const message = error instanceof Error ? error.message : "Unknown error";
            alert("Migration Failed: " + message);
        } finally {
            setIsMigrating(false);
        }
    };

    return { migrateData, isMigrating, migrationStatus, progress };
};
