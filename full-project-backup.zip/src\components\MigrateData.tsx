import React from 'react';
import { useMigration } from '../hooks/useMigration';

const MigrateData: React.FC = () => {
    const { migrateData, isMigrating, migrationStatus, progress } = useMigration();

    return (
        <div className="p-8 max-w-2xl mx-auto bg-white rounded-xl shadow-md border border-gray-100">
            <h1 className="text-2xl font-bold mb-6">Database Migration Tool</h1>
            <p className="mb-6 text-gray-600">
                This tool converts legacy `repair_prices` (document per device) into the new granular format (document per issue).
                Please ensure you have a backup before running this.
            </p>

            <div className="mb-8 p-4 bg-yellow-50 border border-yellow-200 rounded-lg text-sm text-yellow-800">
                <strong>Warning:</strong> This operation writes heavily to Firestore. Do not close the window while running.
            </div>

            <div className="flex flex-col gap-4">
                <button
                    onClick={migrateData}
                    disabled={isMigrating}
                    className="px-6 py-3 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                    {isMigrating ? 'Migrating...' : 'Start Migration'}
                </button>

                {isMigrating && (
                    <div className="space-y-2">
                        <div className="flex justify-between text-sm font-medium text-gray-700">
                            <span>Progress</span>
                            <span>{progress}%</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div
                                className="h-full bg-blue-600 transition-all duration-300 ease-out"
                                style={{ width: `${progress}%` }}
                            />
                        </div>
                    </div>
                )}

                {migrationStatus && (
                    <div className="mt-4 p-4 bg-gray-50 rounded-lg font-mono text-sm border border-gray-200">
                        {migrationStatus}
                    </div>
                )}
            </div>
        </div>
    );
};

export default MigrateData;
