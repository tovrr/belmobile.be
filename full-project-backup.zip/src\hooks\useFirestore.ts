'use client';

import { useState, useEffect } from 'react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { Product, Shop, Service, BlogPost, RepairPricing, RepairPriceRecord, Reservation, Quote, FranchiseApplication } from '../types';

export const useProducts = () => {
    const [products, setProducts] = useState<Product[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const unsub = onSnapshot(collection(db, 'products'), (snapshot) => {
            const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product));
            setProducts(data);
            setLoading(false);
        }, (error) => {
            console.error("Error fetching products:", error);
            setLoading(false);
        });
        return () => unsub();
    }, []);

    return { products, loading };
};

export const useShops = () => {
    const [shops, setShops] = useState<Shop[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const unsub = onSnapshot(collection(db, 'shops'), (snapshot) => {
            const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Shop));
            setShops(data);
            setLoading(false);
        }, (error) => {
            console.error("Error fetching shops:", error);
            setLoading(false);
        });
        return () => unsub();
    }, []);

    return { shops, loading };
};

export const useServices = () => {
    const [services, setServices] = useState<Service[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const unsub = onSnapshot(collection(db, 'services'), (snapshot) => {
            const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Service));
            setServices(data);
            setLoading(false);
        }, (error) => {
            console.error("Error fetching services:", error);
            setLoading(false);
        });
        return () => unsub();
    }, []);

    return { services, loading };
};

export const useBlogPosts = () => {
    const [posts, setPosts] = useState<BlogPost[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const q = query(collection(db, 'blog_posts'), orderBy('date', 'desc'));
        const unsub = onSnapshot(q, (snapshot) => {
            const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as BlogPost));
            setPosts(data);
            setLoading(false);
        }, (error) => {
            console.error("Error fetching blog posts:", error);
            setLoading(false);
        });
        return () => unsub();
    }, []);

    return { posts, loading };
};

export const useRepairPrices = () => {
    const [prices, setPrices] = useState<RepairPricing[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        let pricesRaw: RepairPriceRecord[] = [];
        let pricingRaw: RepairPriceRecord[] = [];

        const aggregateAndSet = () => {
            const aggregated: Record<string, Record<string, { price: number; priority: number; updatedAt?: string; sourceId?: string }>> = {};

            const standardizeDeviceId = (id: string): string => {
                let clean = id.toLowerCase()
                    .replace(/-reparation$/, '')
                    .replace(/-prix$/, '')
                    .replace(/[^a-z0-9]+/g, '-')
                    .replace(/^-+|-+$/g, '');
                if (clean.startsWith('iphone')) clean = 'apple-' + clean;
                if (clean.startsWith('ipad')) clean = 'apple-' + clean;
                if (clean.startsWith('galaxy-s') || clean.startsWith('galaxy-a')) clean = 'samsung-' + clean;
                if (clean.startsWith('nintendo') && !clean.includes('switch')) clean = 'nintendo-switch';
                if (clean === 'switch' || clean === 'switch-lite' || clean === 'switch-oled') clean = 'nintendo-' + clean;

                const brands = ['apple', 'samsung', 'google', 'huawei', 'nintendo', 'sony', 'microsoft', 'xiaomi', 'oppo', 'realme', 'motorola'];
                for (const brand of brands) {
                    const doublePrefix = `${brand}-${brand}-`;
                    if (clean.startsWith(doublePrefix)) {
                        clean = clean.replace(doublePrefix, `${brand}-`);
                    }
                }
                return clean;
            };

            const processRecord = (record: RepairPriceRecord, sourceTag: string) => {
                const rawId = record.deviceId || record.id || '';
                const deviceId = standardizeDeviceId(rawId);
                const { issueId, variants, price, isActive = true, updatedAt } = record;
                const sourcePriority = sourceTag === 'legacy_pricing' ? 15 : 0;

                if (!deviceId || !isActive) return;

                // DIAGNOSTIC for user's specific problematic device
                const isTarget = deviceId.includes('17-pro-max') || deviceId.includes('iphone-17');
                if (isTarget) {
                    console.warn(`[DIAGNOSTIC] found ${deviceId} in ${sourceTag}. rawId: ${rawId}. Record:`, record);
                }

                const setPrice = (key: string, val: number, basePriority: number) => {
                    if (!aggregated[deviceId]) aggregated[deviceId] = {};
                    const deviceAggregate = aggregated[deviceId];

                    const isSystemDefault = val === 110 || val === 180 || val === 120 || val === 90;
                    const looksManual = val > 0 && !isSystemDefault && val !== 199 && val !== 349 && val !== 499;
                    const isManual = record.isManual || record.migrationSource || val === 0 || val === -1 || basePriority >= 10 || looksManual;

                    const effectivePriority = isManual ? (basePriority + sourcePriority + 25) : (basePriority + sourcePriority);

                    const existing = deviceAggregate[key];
                    const existingTimestamp = existing?.updatedAt ? new Date(existing.updatedAt).getTime() : 0;
                    const currentTimestamp = updatedAt ? new Date(updatedAt).getTime() : 0;

                    if (!existing || effectivePriority > existing.priority || (effectivePriority === existing.priority && currentTimestamp >= existingTimestamp)) {
                        if (isTarget) {
                            console.warn(`  -> ${deviceId}:${key} updated to ${val} (Priority ${effectivePriority} from ${sourceTag})`);
                        }
                        deviceAggregate[key] = { price: val, priority: effectivePriority, updatedAt, sourceId: rawId };
                    }
                };

                if (issueId) {
                    if (issueId === 'screen' && variants?.quality) {
                        let q = variants.quality.toLowerCase();
                        if (q === 'generic-lcd') q = 'generic';
                        if (q === 'oled-soft') q = 'oled';
                        if (q === 'original-refurb' || q === 'service-pack') q = 'original';
                        setPrice(`screen_${q}`, price, 1);
                    } else if (issueId === 'screen' && variants?.position) {
                        setPrice(`screen_${variants.position.toLowerCase()}`, price, 1);
                    } else {
                        setPrice(issueId, price, 1);
                    }
                } else {
                    const legacyIssueFields = [
                        'screen_generic', 'screen_oled', 'screen_original', 'battery', 'charging_port',
                        'housing', 'full_housing', 'chassis', 'rear_glass', 'back_glass',
                        'camera_rear', 'camera_front', 'audio', 'buttons', 'water', 'diagnostic', 'software_repair',
                        'microsoldering', 'shipping', 'other_repair'
                    ];

                    legacyIssueFields.forEach(field => {
                        const legacyData = record as unknown as Record<string, unknown>;
                        const val = legacyData[field];

                        // Handle Variations: full_housing -> housing
                        let targetKey = field;
                        if (field === 'full_housing' || field === 'chassis') targetKey = 'housing';
                        if (field === 'rear_glass') targetKey = 'back_glass';

                        if (val !== undefined) setPrice(targetKey, val as number, 10);

                        if (legacyData.prices && typeof legacyData.prices === 'object') {
                            const nested = legacyData.prices as Record<string, unknown>;
                            if (nested[field] !== undefined) setPrice(targetKey, nested[field] as number, 10);
                        }
                    });
                }

                // FORENSIC PRICE HUNTER: Look for "650" (or any other manual price) everywhere
                const hunterTargetValue = 650;
                Object.entries(record as any).forEach(([key, val]) => {
                    const isManualIndicator = val === hunterTargetValue || val === 0 || val === -1 || (typeof val === 'number' && val > 0 && ![110, 180, 120, 90, 199, 349, 499].includes(val));

                    if (isManualIndicator) {
                        console.warn(`[HUNTER] Found potential manual data in ${sourceTag}! Device: ${deviceId}, Key: ${key}, Value: ${val}, RawID: ${rawId}`);
                    }

                    if (key === 'prices' && typeof val === 'object' && val !== null) {
                        Object.entries(val).forEach(([innerKey, innerVal]) => {
                            const isNestedManual = innerVal === hunterTargetValue || innerVal === 0 || innerVal === -1 || (typeof innerVal === 'number' && innerVal > 0 && ![110, 180, 120, 90, 199, 349, 499].includes(innerVal));
                            if (isNestedManual) {
                                console.warn(`[HUNTER] Found potential manual data in ${sourceTag} (NESTED)! Device: ${deviceId}, Key: ${innerKey}, Value: ${innerVal}, RawID: ${rawId}`);
                            }
                        });
                    }
                });
            };

            // Order matters: pricingRaw (sourcePriority 15) vs pricesRaw (sourcePriority 0)
            // But setPrice logic uses higher priority wins, so order doesn't strictly matter if priorities are correct.
            pricesRaw.forEach(r => processRecord(r, 'standard_prices'));
            pricingRaw.forEach(r => processRecord(r, 'legacy_pricing'));

            const finalPrices: RepairPricing[] = Object.keys(aggregated).map(dId => {
                const deviceObj: Record<string, any> = { id: dId };
                Object.entries(aggregated[dId]).forEach(([key, value]) => {
                    deviceObj[key] = value.price;
                });
                return deviceObj as RepairPricing;
            });

            console.log(`[useRepairPrices] Unified data ready. Devices: ${finalPrices.length}`);
            setPrices(finalPrices);
            setLoading(false);
        };

        const unsub1 = onSnapshot(collection(db, 'repair_prices'), (snap) => {
            console.log(`[useRepairPrices] 'repair_prices' update: ${snap.docs.length} docs`);
            pricesRaw = snap.docs.map(d => ({ id: d.id, ...d.data() } as RepairPriceRecord));
            aggregateAndSet();
        }, (error) => {
            console.error("Error fetching 'repair_prices':", error);
        });

        const unsub2 = onSnapshot(collection(db, 'repair_pricing'), (snap) => {
            if (snap.docs.length > 0) {
                console.warn(`[RECOVERY] FOUND ${snap.docs.length} docs in 'repair_pricing'!`);
            }
            pricingRaw = snap.docs.map(d => ({ id: d.id, ...d.data() } as RepairPriceRecord));
            aggregateAndSet();
        }, (error) => {
            // pricing collection might not exist in all environments, so we log as warning
            console.warn("Could not fetch 'repair_pricing' collection. This is normal if it doesn't exist yet.");
            pricingRaw = [];
            aggregateAndSet();
        });

        return () => { unsub1(); unsub2(); };
    }, []);

    return { prices, loading };
};

export const useReservations = () => {
    const [reservations, setReservations] = useState<Reservation[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (!auth.currentUser) {
            const timeoutId = setTimeout(() => setLoading(false), 0);
            return () => clearTimeout(timeoutId);
        }
        const q = query(collection(db, 'reservations'), orderBy('date', 'desc'));
        const unsub = onSnapshot(q, (snapshot) => {
            const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Reservation));
            setReservations(data);
            setLoading(false);
        }, (error) => {
            console.error("Error fetching reservations:", error);
            setLoading(false);
        });
        return () => unsub();
    }, []);

    return { reservations, loading };
};

export const useQuotes = () => {
    const [quotes, setQuotes] = useState<Quote[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (!auth.currentUser) {
            const timeoutId = setTimeout(() => setLoading(false), 0);
            return () => clearTimeout(timeoutId);
        }
        const q = query(collection(db, 'quotes'), orderBy('date', 'desc'));
        const unsub = onSnapshot(q, (snapshot) => {
            const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Quote));
            setQuotes(data);
            setLoading(false);
        }, (error) => {
            console.error("Error fetching quotes:", error);
            setLoading(false);
        });
        return () => unsub();
    }, []);

    return { quotes, loading };
};

export const useFranchiseApplications = () => {
    const [applications, setApplications] = useState<FranchiseApplication[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (!auth.currentUser) {
            const timeoutId = setTimeout(() => setLoading(false), 0);
            return () => clearTimeout(timeoutId);
        }
        const unsub = onSnapshot(collection(db, 'franchise_applications'), (snapshot) => {
            const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as FranchiseApplication));
            setApplications(data);
            setLoading(false);
        }, (error) => {
            console.error("Error fetching franchise applications:", error);
            setLoading(false);
        });
        return () => unsub();
    }, []);

    return { applications, loading };
};
