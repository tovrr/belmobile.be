import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

import { i18n } from './i18n-config';
import { LEGACY_URL_MAP } from './utils/legacyUrlMap';

const LOCALES = i18n.locales;
const DEFAULT_LOCALE = i18n.defaultLocale;

// Path Translations Map (Localized -> Canonical)
const PATH_TRANSLATIONS: Record<string, Record<string, string>> = {
    fr: {
        'produits': 'products',
        'reparation': 'repair',
        'rachat': 'buyback',
        'acheter': 'buy',
        'magasins': 'stores',
        'contact': 'contact',
        'faq': 'faq',
        'blog': 'blog',
        'carrieres': 'jobs',
        'solutions-business': 'business',
        'franchise': 'franchise',
        'suivre-commande': 'track-order',
        'conditions': 'terms',
        'confidentialite': 'privacy',
        'garantie': 'warranty',
    },
    nl: {
        'producten': 'products',
        'reparatie': 'repair',
        'inkoop': 'buyback',
        'kopen': 'buy',
        'winkels': 'stores',
        'contact': 'contact',
        'faq': 'faq',
        'blog': 'blog',
        'vacatures': 'jobs',
        'zakelijk': 'business',
        'franchise': 'franchise',
        'volg-bestelling': 'track-order',
        'voorwaarden': 'terms',
        'privacy': 'privacy',
        'garantie': 'warranty',
    }
};

export function proxy(request: NextRequest) {
    const pathname = request.nextUrl.pathname;

    // 0. SEO Legacy Redirects (Explicit 301/308)
    // Normalize path (remove trailing slash)
    const normalizedPath = pathname.endsWith('/') && pathname.length > 1 ? pathname.slice(0, -1) : pathname;

    // Check exact match in Legacy Map
    if (LEGACY_URL_MAP[normalizedPath]) {
        const target = LEGACY_URL_MAP[normalizedPath];
        return NextResponse.redirect(new URL(target, request.url), 308); // 308 Permanent Redirect
    }

    // 1. Check if path starts with a locale
    const pathnameIsMissingLocale = LOCALES.every(
        (locale) => !pathname.startsWith(`/${locale}/`) && pathname !== `/${locale}`
    );

    // Redirect if no locale (except for static files, api, etc.)
    if (pathnameIsMissingLocale) {
        // Exclude internal paths
        if (
            pathname.startsWith('/_next') ||
            pathname.startsWith('/api') ||
            pathname.startsWith('/admin') || // Exclude admin routes
            pathname.startsWith('/migrate') || // Exclude migration route
            pathname.includes('.') // files like favicon.ico
        ) {
            return NextResponse.next();
        }

        const locale = DEFAULT_LOCALE;
        return NextResponse.redirect(
            new URL(`/${locale}${pathname.startsWith('/') ? '' : '/'}${pathname}`, request.url)
        );
    }

    // 2. Handle Localized Path Rewrites
    const segments = pathname.split('/').filter(Boolean);
    const locale = segments[0];
    const pathSegment = segments[1]; // The first segment after locale

    if (locale && pathSegment && PATH_TRANSLATIONS[locale]) {
        const canonical = PATH_TRANSLATIONS[locale][pathSegment];
        if (canonical) {
            // Replace the localized segment with the canonical one
            segments[1] = canonical;
            const newPath = `/${segments.join('/')}`;

            // Rewrite the URL (internal redirect, user sees original URL)
            return NextResponse.rewrite(new URL(newPath, request.url));
        }
    }

    return NextResponse.next();
}

export const config = {
    matcher: [
        // Skip all internal paths (_next)
        '/((?!_next|api|favicon.ico).*)',
    ],
};

export default proxy;
