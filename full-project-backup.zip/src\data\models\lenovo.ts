export const MODELS = {
    tablet: { 'Tab P11 Pro': 250, 'Yoga Tab 13': 350 },
    laptop: { 'ThinkPad X1 Carbon': 1000, 'IdeaPad 5': 450 }
};

export const SPECS = {};
