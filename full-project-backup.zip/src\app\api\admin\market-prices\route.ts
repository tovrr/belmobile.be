import { NextRequest, NextResponse } from 'next/server';
import { fetchMarketData } from '@/lib/market-intelligence/scrapers';

export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { brand, model } = body;

        if (!brand || !model) {
            return NextResponse.json({ error: 'Brand and Model are required' }, { status: 400 });
        }

        console.log(`[API] Market Price Scan requested for: ${brand} ${model}`);

        const data = await fetchMarketData(brand, model);

        if (!data) {
            return NextResponse.json({ error: 'Could not fetch market data' }, { status: 404 });
        }

        return NextResponse.json(data);

    } catch (error) {
        console.error('[API] Market Price Error:', error);
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
    }
}
