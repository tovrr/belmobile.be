export const MODELS = {
    laptop: { 'XPS 13': 900, 'Inspiron 15': 400 }
};

export const SPECS = {
    'XPS 13': ['512GB', '1TB']
};
