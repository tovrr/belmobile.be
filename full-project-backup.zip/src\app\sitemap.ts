import { MetadataRoute } from 'next';
import { SERVICES } from '../data/services';
import { LOCATIONS } from '../data/locations';
import { DEVICE_BRANDS } from '../data/brands';
import { createSlug } from '../utils/slugs';

// Import Models
import { MODELS as AppleModels } from '../data/models/apple';
import { MODELS as SamsungModels } from '../data/models/samsung';
import { MODELS as GoogleModels } from '../data/models/google';
import { MODELS as HuaweiModels } from '../data/models/huawei';
import { MODELS as OnePlusModels } from '../data/models/oneplus';
import { MODELS as XiaomiModels } from '../data/models/xiaomi';
import { MODELS as OppoModels } from '../data/models/oppo';
import { MODELS as SonyModels } from '../data/models/sony';
import { MODELS as MicrosoftModels } from '../data/models/microsoft';
import { MODELS as LenovoModels } from '../data/models/lenovo';
import { MODELS as HPModels } from '../data/models/hp';
import { MODELS as DellModels } from '../data/models/dell';
import { MODELS as NintendoModels } from '../data/models/nintendo';
import { MODELS as XboxModels } from '../data/models/xbox';

const BASE_URL = process.env.NEXT_PUBLIC_BASE_URL || 'https://belmobile.be';

const MODEL_DATA: Record<string, any> = {
    'apple': AppleModels,
    'samsung': SamsungModels,
    'google': GoogleModels,
    'huawei': HuaweiModels,
    'oneplus': OnePlusModels,
    'xiaomi': XiaomiModels,
    'oppo': OppoModels,
    'sony': SonyModels,
    'microsoft': MicrosoftModels,
    'lenovo': LenovoModels,
    'hp': HPModels,
    'dell': DellModels,
    'nintendo': NintendoModels,
    'xbox': XboxModels,
};

export default function sitemap(): MetadataRoute.Sitemap {
    const sitemap: MetadataRoute.Sitemap = [];
    const languages = ['fr', 'nl', 'en'];

    // 1. Static Pages & Home
    languages.forEach(lang => {
        sitemap.push({
            url: `${BASE_URL}/${lang}`,
            lastModified: new Date(),
            changeFrequency: 'daily',
            priority: 1.0,
        });
    });

    // 2. Services
    SERVICES.forEach(service => {
        if (service.id === 'products') return; // Skip products for now, focus on repair/buyback

        languages.forEach(lang => {
            const serviceSlug = service.slugs[lang as keyof typeof service.slugs];

            // Level 1: Service Home (e.g., /fr/reparation)
            sitemap.push({
                url: `${BASE_URL}/${lang}/${serviceSlug}`,
                lastModified: new Date(),
                changeFrequency: 'daily',
                priority: 0.9,
            });

            // Level 2: Service + Location (e.g., /fr/reparation/bruxelles)
            LOCATIONS.forEach(location => {
                const locationSlug = location.slugs[lang as keyof typeof location.slugs];
                sitemap.push({
                    url: `${BASE_URL}/${lang}/${serviceSlug}/${locationSlug}`,
                    lastModified: new Date(),
                    changeFrequency: 'weekly',
                    priority: 0.85,
                });
            });

            // Level 3: Service + Brand
            Object.entries(DEVICE_BRANDS).forEach(([deviceType, brands]) => {
                brands.forEach(brand => {
                    const brandSlug = createSlug(brand);

                    // Service + Brand (e.g., /fr/reparation/apple)
                    sitemap.push({
                        url: `${BASE_URL}/${lang}/${serviceSlug}/${brandSlug}`,
                        lastModified: new Date(),
                        changeFrequency: 'weekly',
                        priority: 0.8,
                    });

                    // Service + Brand + Location (e.g., /fr/reparation/apple/bruxelles)
                    LOCATIONS.forEach(location => {
                        const locationSlug = location.slugs[lang as keyof typeof location.slugs];
                        sitemap.push({
                            url: `${BASE_URL}/${lang}/${serviceSlug}/${brandSlug}/${locationSlug}`,
                            lastModified: new Date(),
                            changeFrequency: 'weekly',
                            priority: 0.75,
                        });
                    });

                    // Level 4: Service + Brand + Model
                    const modelsData = MODEL_DATA[brandSlug];
                    if (modelsData) {
                        // modelsData is structured by category: { smartphone: { ... }, tablet: { ... } }
                        // We should only look for models in the current deviceType category if it exists
                        const categoryModels = modelsData[deviceType];

                        if (categoryModels) {
                            Object.keys(categoryModels).forEach(modelName => {
                                const modelSlug = createSlug(modelName);

                                // Service + Brand + Model (e.g., /fr/reparation/apple/iphone-13)
                                sitemap.push({
                                    url: `${BASE_URL}/${lang}/${serviceSlug}/${brandSlug}/${modelSlug}`,
                                    lastModified: new Date(),
                                    changeFrequency: 'weekly',
                                    priority: 0.7,
                                });

                                // Service + Brand + Model + Location (e.g., /fr/reparation/apple/iphone-13/bruxelles)
                                LOCATIONS.forEach(location => {
                                    const locationSlug = location.slugs[lang as keyof typeof location.slugs];
                                    sitemap.push({
                                        url: `${BASE_URL}/${lang}/${serviceSlug}/${brandSlug}/${modelSlug}/${locationSlug}`,
                                        lastModified: new Date(),
                                        changeFrequency: 'monthly',
                                        priority: 0.6,
                                    });
                                });
                            });
                        }
                    }
                });
            });
        });
    });

    return sitemap;
}
