# 🚀 GRAND LANCEMENT: STRATÉGIE SEO BELMOBILE.BE

Ce document détaille l'architecture SEO avancée mise en place pour dominer les résultats de recherche locaux et nationaux pour la réparation et le rachat de smartphones/consoles.

## 1. Architecture SEO (Next.js App Router)

Nous utilisation l'API `Metadata` native de Next.js 14+ pour générer dynamiquement tout le contenu SEO côté serveur (SSR), garantissant une indexation parfaite par Google.

### Structure des URLs
L'architecture d'URL est conçue pour capturer le trafic "Long Tail" (Recherche Ultra-Précise) :

`/{lang}/{service}/{device-brand}/{device-model}/{location}`

**Exemples :**
*   `/fr/reparation/apple/iphone-13/bruxelles`
*   `/nl/herstelling/samsung/galaxy-s23/anderlecht`
*   `/en/repair/sony/playstation-5/schaerbeek`

## 2. Gestion Dynamique des Meta Tags (`[...slug]/page.tsx`)

Le fichier `src/app/[lang]/[...slug]/page.tsx` est le moteur central. Il analyse l'URL et génère les balises optimisées à la volée.

### La "Golden Formula" pour les Titres
Nous construisons les titres selon une formule éprouvée pour maximiser le CTR (Taux de Clic) :

`[Service] [Appareil] [Lieu] - [Proposition de Valeur]`

*   **Exemple PS5 :** "Réparation PlayStation 5 Bruxelles - HDMI & Nettoyage"
*   **Exemple iPhone :** "Réparation iPhone 13 Schaerbeek - Prix & 30 min"

### Injection Dynamique de Contenu (Dynamic Injection)
Nous injectons des données temps-réel dans la Meta Description pour augmenter la pertinence :

1.  **Prix "À partir de" :**
    *   Le système scanne la base de données tarifaire.
    *   Il trouve le prix le plus bas non-nul pour l'appareil.
    *   *Resultat :* "...Remplacement écran à partir de €89..."
2.  **Mots-clés Spécialisés :**
    *   Si l'appareil est une **PlayStation 5**, nous injectons automatiquement "HDMI" et "Nettoyage/Pâte Thermique" dans le titre et la description, car ce sont les pannes les plus recherchées.

## 3. Données Structurées (Schema.org / JSON-LD)

Nous utilisons `src/components/seo/SchemaOrg.tsx` pour "parler" directement aux robots Google.

### Types de Schémas Implémentés :
*   `MobilePhoneStore` / `LocalBusiness` : Pour les pages magasins (avec heures d'ouverture, géolocalisation).
*   `Service` :
    *   `MobilePhoneRepair` : Pour smartphones/tablettes.
    *   **`GameConsoleRepair` (NOUVEAU)** : Spécifique pour Sony/Xbox/Nintendo.
*   `Product` / `Offer` : Pour les pages de rachat/vente.
*   `BreadcrumbList` : Pour afficher le fil d'ariane dans les résultats de recherche.
*   `FAQPage` : Pour les pages FAQ.

> **Impact :** Cela permet d'afficher les "Rich Snippets" (étoiles, prix, stocks) directement dans Google.

## 4. Gestion des URLs et Redirections (`middleware.ts`)

### Internationalisation (i18n)
Le `middleware.ts` assure que chaque utilisateur est redirigé vers sa langue ou la langue par défaut (`/fr`).

### Traduction des Slugs
Les URLs sont traduites mais canoniques.
*   FR: `/fr/reparation`
*   NL: `/nl/reparatie`
*   EN: `/en/repair`

Le système map automatiquement ces variations vers un contexte unique pour le rendu, tout en servant les bonnes balises `hreflang` pour éviter le contenu dupliqué (Géré par `components/seo/Hreflang.tsx`).

## 5. Slugs et Normalisation

Nous utilisons un générateur de slugs strict (`utils/slugs.ts`) pour éviter les URLs dupliquées (e.g., `iPhone 13` -> `iphone-13`).
Le système est capable de faire l'inverse (`iphone-13` -> `iPhone 13`) pour afficher des titres propres sur la page.

## ✅ Action Plan : Prochaines Étapes

1.  **Seeding des Prix (URGENT) :**
    *   Utiliser l'outil Admin > Batch Tools > "Seed ALL Supported Brands".
    *   Cela va peupler la DB avec les prix PS5/Consoles nécessaires pour l'injection SEO ("à partir de X€").

2.  **Sitemap XML :**
    *   Le fichier `src/app/sitemap.ts` génère déjà automatiquement toutes les combinaisons possibles (Langue x Service x Marque x Modèle x Lieu).
    *   **Action :** Soumettre `https://belmobile.be/sitemap.xml` à la Google Search Console après le déploiement.

3.  **Vérification :**
    *   Utiliser l'outil [Schema Markup Validate](https://validator.schema.org/) sur une page produit (ex: `/fr/reparation/sony/playstation-5`) pour vérifier que le type `GameConsoleRepair` est bien détecté.
