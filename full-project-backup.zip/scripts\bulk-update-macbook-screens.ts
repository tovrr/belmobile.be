/**
 * Bulk Update Script: Disable Generic/OLED screens for all Macbooks
 * 
 * This script sets screen_generic and screen_oled to -1 for all MacBook models
 * in the repair pricing database, leaving only screen_original active.
 * 
 * Run with: npx tsx scripts/bulk-update-macbook-screens.ts
 */

import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs, updateDoc, doc } from 'firebase/firestore';

// Firebase config (from your project)
const firebaseConfig = {
    apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
    authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
    projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
    storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
    messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
    appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

async function bulkUpdateMacbookScreens() {
    console.log('🔍 Fetching all repair prices...');

    const repairPricesRef = collection(db, 'repairPrices');
    const snapshot = await getDocs(repairPricesRef);

    console.log(`📊 Found ${snapshot.size} total repair price entries`);

    let updatedCount = 0;
    let skippedCount = 0;

    for (const docSnapshot of snapshot.docs) {
        const data = docSnapshot.data();
        const id = data.id || docSnapshot.id;

        // Check if this is a MacBook (contains "macbook" in the ID)
        if (id.toLowerCase().includes('macbook')) {
            console.log(`\n📝 Processing: ${id}`);

            // Check current values
            const currentGeneric = data.screen_generic;
            const currentOled = data.screen_oled;
            const currentOriginal = data.screen_original;

            console.log(`   Current: Generic=${currentGeneric}, OLED=${currentOled}, Original=${currentOriginal}`);

            // Only update if Generic or OLED are not already -1
            if (currentGeneric !== -1 || currentOled !== -1) {
                await updateDoc(doc(db, 'repairPrices', docSnapshot.id), {
                    screen_generic: -1,
                    screen_oled: -1,
                    updatedAt: new Date()
                });

                console.log(`   ✅ Updated: Generic=-1, OLED=-1, Original=${currentOriginal}`);
                updatedCount++;
            } else {
                console.log(`   ⏭️  Skipped: Already configured correctly`);
                skippedCount++;
            }
        }
    }

    console.log('\n' + '='.repeat(60));
    console.log('✨ Bulk update complete!');
    console.log(`   📊 Total MacBooks found: ${updatedCount + skippedCount}`);
    console.log(`   ✅ Updated: ${updatedCount}`);
    console.log(`   ⏭️  Skipped: ${skippedCount}`);
    console.log('='.repeat(60));
}

// Run the script
bulkUpdateMacbookScreens()
    .then(() => {
        console.log('\n✅ Script completed successfully');
        process.exit(0);
    })
    .catch((error) => {
        console.error('\n❌ Error:', error);
        process.exit(1);
    });
