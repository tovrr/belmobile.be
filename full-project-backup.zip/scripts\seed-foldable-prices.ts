import { initializeApp } from 'firebase/app';
import { getFirestore, doc, setDoc } from 'firebase/firestore';

// Firebase config (use your actual config)
const firebaseConfig = {
    apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
    authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
    projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
    storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
    messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
    appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const foldablePrices = [
    // Galaxy Z Fold Series
    { model: 'Galaxy Z Fold7', slug: 'samsung-galaxy-z-fold7', inner: 749, outer: 139 },
    { model: 'Galaxy Z Fold6', slug: 'samsung-galaxy-z-fold6', inner: 689, outer: 134 },
    { model: 'Galaxy Z Fold5', slug: 'samsung-galaxy-z-fold5', inner: 619, outer: 119 },
    { model: 'Galaxy Z Fold4', slug: 'samsung-galaxy-z-fold4', inner: 529, outer: 104 },
    { model: 'Galaxy Z Fold3', slug: 'samsung-galaxy-z-fold3', inner: 469, outer: 97 },
    { model: 'Galaxy Z Fold2', slug: 'samsung-galaxy-z-fold2', inner: 439, outer: 168 },

    // Galaxy Z Flip Series
    { model: 'Galaxy Z Flip7', slug: 'samsung-galaxy-z-flip7', inner: 445, outer: 84 },
    { model: 'Galaxy Z Flip6', slug: 'samsung-galaxy-z-flip6', inner: 389, outer: 77 },
    { model: 'Galaxy Z Flip5', slug: 'samsung-galaxy-z-flip5', inner: 385, outer: 75 },
    { model: 'Galaxy Z Flip4', slug: 'samsung-galaxy-z-flip4', inner: 411, outer: 75 },
    { model: 'Galaxy Z Flip3', slug: 'samsung-galaxy-z-flip3', inner: 347, outer: 70 },
    { model: 'Galaxy Z Flip 5G', slug: 'samsung-galaxy-z-flip-5g', inner: 305, outer: 63 },
];

async function seedFoldablePrices() {
    console.log('🚀 Starting foldable screen price seeding...\n');

    let successCount = 0;
    let errorCount = 0;

    for (const device of foldablePrices) {
        try {
            // Inner Screen
            const innerDocId = `${device.slug}_screen_foldable_inner`;
            await setDoc(doc(db, 'repair_pricing', innerDocId), {
                deviceId: device.slug,
                issueId: 'screen_foldable_inner',
                variants: {},
                price: device.inner,
                currency: 'EUR',
                isActive: true,
                updatedAt: new Date().toISOString()
            });
            console.log(`✅ ${device.model} - Inner Screen: €${device.inner}`);
            successCount++;

            // Outer Screen
            const outerDocId = `${device.slug}_screen_foldable_outer`;
            await setDoc(doc(db, 'repair_pricing', outerDocId), {
                deviceId: device.slug,
                issueId: 'screen_foldable_outer',
                variants: {},
                price: device.outer,
                currency: 'EUR',
                isActive: true,
                updatedAt: new Date().toISOString()
            });
            console.log(`✅ ${device.model} - Outer Screen: €${device.outer}\n`);
            successCount++;

        } catch (error) {
            console.error(`❌ Error seeding ${device.model}:`, error);
            errorCount++;
        }
    }

    console.log('\n📊 Seeding Summary:');
    console.log(`   ✅ Success: ${successCount} prices added`);
    console.log(`   ❌ Errors: ${errorCount}`);
    console.log('\n🎉 Done! Refresh your admin panel to see the new prices.');
}

seedFoldablePrices()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error('Fatal error:', error);
        process.exit(1);
    });
