'use client';

import MigrateData from '../../components/MigrateData';

export default function MigratePage() {
    return <MigrateData />;
}
