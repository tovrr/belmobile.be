'use client';

import SEOManagement from '../../../components/admin/SEOManagement';

export default function GlobalSEOPage() {
    return <SEOManagement />;
}
