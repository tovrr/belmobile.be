'use client';

import React from 'react';
import Settings from '../../../components/admin/Settings';

export default function SettingsPage() {
    return (
        <div className="max-w-7xl mx-auto">
            <Settings />
        </div>
    );
}
