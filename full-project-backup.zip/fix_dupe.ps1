$path = "src/components/admin/RepairPricingMatrix.tsx"
$content = Get-Content $path
$part1 = $content[0..803]
$part2 = $content[986..($content.Count - 1)]
$newContent = $part1 + $part2
$newContent | Set-Content $path -Encoding UTF8
Write-Host "Done. Lines: $($newContent.Count)"
