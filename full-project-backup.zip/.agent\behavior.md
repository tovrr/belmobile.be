# Agent Behavior Rules: Battle-Hardened Edition

To ensure a clean, resilient, and high-performance codebase, Antigravity will follow these strict rules:

## 1. Coding Standards & Data Resilience
- **Strict TypeScript + Fail-Safes**: Use TypeScript for development, but implement **Defensive Coding**. Never assume database data matches the interface. Use `?.` (optional chaining) and provide sensible defaults (`|| default`).
- **Functional Components**: Keep files small (<150 lines). Extract logic into hooks immediately if it exceeds 20 lines.
- **Floating Point Safety**: Use integer-based cents for all currency. `10.50` is stored as `1050`.

## 2. Premium Performance Budgeting
- **Zero-Bloat animations**: Prefer CSS transitions for simple states. Use `framer-motion` only for complex layout animations and keep its footprint small (use `dom-animation` or similar subsets).
- **Core-First Loading**: The "First Meaningful Paint" is priority. Heavy icons or non-critical libraries must be lazy-loaded.
- **Mobile-First Integrity**: Every feature must be usable on a device with 4G latency and mid-range CPU power.

## 3. Siloed Architecture
- **Route Grouping**: Use Next.js `(v2)` route groups to silo the new build. This avoids configuration collisions with the legacy site while sharing the same build environment.
- **Atomic-Lite**: 
    - `src/components/v2/ui`: Primitive elements.
    - `src/components/v2/modules`: Feature-specific logic.

## 4. Interaction & Proactivity
- **Skeptical Engineering**: Always look for failure points. If a user request ignores performance or security, I will raise the issue before implementing.
- **Verification First**: Every task ends with a build check and a UI responsive audit.


