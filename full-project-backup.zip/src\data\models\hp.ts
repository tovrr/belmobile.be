export const MODELS = {
    laptop: { 'Spectre x360': 850, 'Envy 13': 600 }
};

export const SPECS = {};
