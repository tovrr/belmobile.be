// Run this with: node scripts/add-foldable-prices.js
// Or: npx tsx scripts/add-foldable-prices.ts

const { initializeApp } = require('firebase/app');
const { getFirestore, doc, setDoc } = require('firebase/firestore');

// Your Firebase config
const firebaseConfig = {
    apiKey: "AIzaSyDbBU2HDNb_CravJAIbYKqsWhhbAgVBelY",
    authDomain: "belmobile-be.firebaseapp.com",
    projectId: "belmobile-be",
    storageBucket: "belmobile-be.firebasestorage.app",
    messagingSenderId: "1085893866086",
    appId: "1:1085893866086:web:d9a5f2e0c0a0a0a0a0a0a0"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const foldablePrices = [
    { model: 'Galaxy Z Fold7', slug: 'samsung-galaxy-z-fold7', inner: 749, outer: 139 },
    { model: 'Galaxy Z Fold6', slug: 'samsung-galaxy-z-fold6', inner: 689, outer: 134 },
    { model: 'Galaxy Z Fold5', slug: 'samsung-galaxy-z-fold5', inner: 619, outer: 119 },
    { model: 'Galaxy Z Fold4', slug: 'samsung-galaxy-z-fold4', inner: 529, outer: 104 },
    { model: 'Galaxy Z Fold3', slug: 'samsung-galaxy-z-fold3', inner: 469, outer: 97 },
    { model: 'Galaxy Z Fold2', slug: 'samsung-galaxy-z-fold2', inner: 439, outer: 168 },
    { model: 'Galaxy Z Flip7', slug: 'samsung-galaxy-z-flip7', inner: 445, outer: 84 },
    { model: 'Galaxy Z Flip6', slug: 'samsung-galaxy-z-flip6', inner: 389, outer: 77 },
    { model: 'Galaxy Z Flip5', slug: 'samsung-galaxy-z-flip5', inner: 385, outer: 75 },
    { model: 'Galaxy Z Flip4', slug: 'samsung-galaxy-z-flip4', inner: 411, outer: 75 },
    { model: 'Galaxy Z Flip3', slug: 'samsung-galaxy-z-flip3', inner: 347, outer: 70 },
    { model: 'Galaxy Z Flip 5G', slug: 'samsung-galaxy-z-flip-5g', inner: 305, outer: 63 },
];

async function addPrices() {
    console.log('🚀 Adding foldable screen prices...\n');

    for (const device of foldablePrices) {
        console.log(`📱 ${device.model}`);

        // Inner Screen
        const innerDocId = `${device.slug}_screen_foldable_inner`;
        await setDoc(doc(db, 'repair_pricing', innerDocId), {
            deviceId: device.slug,
            issueId: 'screen_foldable_inner',
            variants: {},
            price: device.inner,
            currency: 'EUR',
            isActive: true,
            updatedAt: new Date().toISOString()
        }, { merge: true });
        console.log(`   ✅ Inner: €${device.inner}`);

        // Outer Screen
        const outerDocId = `${device.slug}_screen_foldable_outer`;
        await setDoc(doc(db, 'repair_pricing', outerDocId), {
            deviceId: device.slug,
            issueId: 'screen_foldable_outer',
            variants: {},
            price: device.outer,
            currency: 'EUR',
            isActive: true,
            updatedAt: new Date().toISOString()
        }, { merge: true });
        console.log(`   ✅ Outer: €${device.outer}\n`);
    }

    console.log('🎉 Done! Added 24 prices for 12 models.');
    process.exit(0);
}

addPrices().catch(error => {
    console.error('❌ Error:', error);
    process.exit(1);
});
